/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this
template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.dao;

import com.model.AbcModel;
import com.util.HibernateUtil;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author ranji
 */
public class AbcDao {
    //insert data in abc database 
    
    public boolean addAbc(AbcModel am){
        
        Session session=HibernateUtil.getSessionFactory().openSession();
        Transaction t=session.getTransaction();
        try {
            
            t.begin();
            session.save(am);
            t.commit();
            return true;
            
            
            
        } catch (Exception e) {
            e.printStackTrace();
            t.rollback();
        }finally{
        session.close();
        }
        
        return false;
        
        
    }
    
    
    //getaalabc details multiple data fetch using list
    
    public List<AbcModel> getAllAbc(){
        
        Session session=HibernateUtil.getSessionFactory().openSession();
        Transaction tx=session.beginTransaction();
        
        try {
            
            Query query=session.createQuery("FROM AbcModel");
            List<AbcModel> abc=query.list();
            tx.commit();
            return abc;
            
        } catch (Exception e) {
            
            e.printStackTrace();
            tx.rollback();
        }finally{
        session.close();
        }
        
        
        return null;
    
    }
    
    //update
     public boolean updateAbc(AbcModel am){
        
        Session session=HibernateUtil.getSessionFactory().openSession();
        Transaction t=session.getTransaction();
        try {
            
            t.begin();
            session.update(am);
            t.commit();
            return true;
            
            
            
        } catch (Exception e) {
            e.printStackTrace();
            t.rollback();
        }finally{
        session.close();
        }
        
        return false;
        
        
    }
    
    //delete
     
     public boolean deleteAbc(AbcModel am){
        
        Session session=HibernateUtil.getSessionFactory().openSession();
        Transaction t=session.getTransaction();
        try {
            
            t.begin();
            session.delete(am);
            t.commit();
            return true;
            
            
            
        } catch (Exception e) {
            e.printStackTrace();
            t.rollback();
        }finally{
        session.close();
        }
        
        return false;
        
        
    }
     
     
//     getbyAbcId
     
     public AbcModel getByAbcId(long id){
        Session session=HibernateUtil.getSessionFactory().openSession();
        Transaction t=session.getTransaction();
        
         try {
             
             Query query=session.createQuery("FROM AbcModel WHERE id=:id");
             query.setParameter("id", id);
             AbcModel a=(AbcModel) query.uniqueResult();
             return a;
             
             
         } catch (Exception e) {
             e.printStackTrace();
             t.rollback();
         }finally{
         session.close();
         }
        
        
         
        return null;
     }
}
